#!/bin/bash
rm -rf flag/*
