import os
import time
from multiprocessing import Process

s_time = time.time()

def scan(ip):
    ip="10.11." + ip
    
    for i in range(0,251):
        if(i%4==0):
            cmd = "fping -agq %s.%d %s.%d >> alive.txt &" %(ip,i,ip,i+3)
            print(cmd)
            os.popen(cmd)


for i in range(125,127):
    s=Process(target=scan,args=(str(i),))
    s.start()
    time.sleep(0.5)




#test 
os.system("python3 middleware.py")

e_time = time.time()
print("\033[32mExploit Completely by %ds" % (e_time-s_time))
