#!/bin/bash
rm -rf flag/*
rm -rf alive.txt
rm -rf flag_contect.txt
